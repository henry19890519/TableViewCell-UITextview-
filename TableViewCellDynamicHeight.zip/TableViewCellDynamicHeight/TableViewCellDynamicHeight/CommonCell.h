//
//  CommonCell.h
//  TableViewCellDynamicHeight
//
//  Created by he on 2017/2/15.
//  Copyright © 2017年 he. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommonCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *NameLabel;
@property (weak, nonatomic) IBOutlet UITextField *MyTXT;

@end
