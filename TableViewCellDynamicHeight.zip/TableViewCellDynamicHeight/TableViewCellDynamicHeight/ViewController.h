//
//  ViewController.h
//  TableViewCellDynamicHeight
//
//  Created by he on 2017/2/15.
//  Copyright © 2017年 he. All rights reserved.
//
#import "CommonCell.h"
#import "TitleCell.h"
#import "InstructionCell.h"
#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UITextViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *MyTableView;


@end

