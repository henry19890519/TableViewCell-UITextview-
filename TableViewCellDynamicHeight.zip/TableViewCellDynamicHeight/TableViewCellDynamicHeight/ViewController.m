//
//  ViewController.m
//  TableViewCellDynamicHeight
//
//  Created by he on 2017/2/15.
//  Copyright © 2017年 he. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.automaticallyAdjustsScrollViewInsets = NO;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.MyTableView registerNib:[UINib nibWithNibName:@"CommonCell" bundle:Nil] forCellReuseIdentifier:@"CommonCell"];
    [self.MyTableView registerNib:[UINib nibWithNibName:@"TitleCell" bundle:Nil] forCellReuseIdentifier:@"TitleCell"];
    [self.MyTableView registerNib:[UINib nibWithNibName:@"InstructionCell" bundle:Nil] forCellReuseIdentifier:@"InstructionCell"];
    
    self.MyTableView.estimatedRowHeight = 100;
    self.MyTableView.rowHeight = UITableViewAutomaticDimension;
    self.MyTableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
}

#pragma mark ---UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 4;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
    CommonCell* cell = [tableView dequeueReusableCellWithIdentifier:@"CommonCell" forIndexPath:indexPath];
    cell.NameLabel.text = @"姓名";
    cell.MyTXT.placeholder = @"请输入姓名";
    return cell;
    }
    else if (indexPath.row == 1){
    CommonCell* cell = [tableView dequeueReusableCellWithIdentifier:@"CommonCell" forIndexPath:indexPath];
    cell.NameLabel.text = @"电话";
    cell.MyTXT.keyboardType = UIKeyboardTypePhonePad;
    cell.MyTXT.placeholder = @"请输入号码";
    return cell;
    }
    else if (indexPath.row == 2){
    TitleCell* cell = [tableView dequeueReusableCellWithIdentifier:@"TitleCell" forIndexPath:indexPath];
    cell.MyTextView.delegate = self;
    return cell;
    }
    else{
    InstructionCell* cell = [tableView dequeueReusableCellWithIdentifier:@"InstructionCell" forIndexPath:indexPath];
    cell.MyTextView.delegate = self;
    return cell;
    }
    
}
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [[[UIApplication sharedApplication] keyWindow] endEditing:NO];
    NSTimeInterval animationDuration = 0.30f;
    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];
    [UIView setAnimationDuration:animationDuration];
    [UIView commitAnimations];
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
#pragma mark ---UITextViewDelegate
- (void)textViewDidChange:(UITextView *)textView
{
    CGRect bounds = textView.bounds;
    // 计算高度
    CGSize maxSize = CGSizeMake(bounds.size.width, CGFLOAT_MAX);
    CGSize newSize = [textView sizeThatFits:maxSize];
    bounds.size = newSize;
    textView.bounds = bounds;
    // 重新计算高度
    [self.MyTableView beginUpdates];
    [self.MyTableView endUpdates];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
