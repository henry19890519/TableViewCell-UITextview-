//
//  InstructionCell.m
//  TableViewCellDynamicHeight
//
//  Created by he on 2017/2/15.
//  Copyright © 2017年 he. All rights reserved.
//

#import "InstructionCell.h"

@implementation InstructionCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
