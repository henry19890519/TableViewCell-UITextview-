//
//  InstructionCell.h
//  TableViewCellDynamicHeight
//
//  Created by he on 2017/2/15.
//  Copyright © 2017年 he. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InstructionCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UITextView *MyTextView;

@end
